# November 2024 election security incident records

This immutable CivicResultMaps release contains 112 mixed-grain incident rows across 10 states. It preserves 110 county rows and 2 statewide-unspecified rows rather than manufacturing county assignments.

The documented minimum of 227 bomb threats comes from the retained Brennan Center public-source tracker and is not an official FBI roster or an exhaustive national count. The separately classified non-bomb-threat row is not added to that total.

These records describe source-linked election-administration and public-safety context. They are not evidence of fraud, misconduct, altered votes, or an incorrect election outcome.
