# 2012 presidential historical baseline snapshot

This immutable CivicResultMaps release contains 2,173 normalized 2012 presidential baseline rows across 28 states. It is a partial historical snapshot, not a complete national county comparison.

Only 120 rows currently carry a reviewed canonical county GEOID. Rows without a canonical tag must not be used as if they were county-comparable. The source_url and row_method columns preserve the source and normalization caveat for each row; 11 states currently rely in whole or in part on explicitly identified secondary-source baselines.

This archive does not include 2012 precinct geometry and does not add 2012 to the live national comparison API. Missing states and untagged rows are data gaps, not zeroes.
