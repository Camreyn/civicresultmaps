# 2024 election equipment context

This immutable CivicResultMaps release contains 3,119 normalized jurisdiction-level equipment-context rows across 50 states. District of Columbia is not present in the retained source files.

The rows are source-linked election-administration context. They do not prove that every precinct, ballot mode, or fielded unit used one identical configuration. Review uniformityWarningRequired, uniformityNote, sourceUrl, and caveat before analysis.

The separate detailed equipment dossier catalog is not included because its editorial lifecycle remains outside this context release. This archive contains no credentials, network addresses, keys, or other operationally sensitive values.
