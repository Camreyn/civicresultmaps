# National county presidential comparison release

Release ID: 2026-07-11-national-county-v1
Published: 2026-07-11T00:00:00.000Z
Geography contract: county:<five-digit Census GEOID>
Geography vintage: 2024 Census county and county-equivalent inventory
Historical geography policy: 2016 and 2020 rows resolve to the current canonical county-equivalent inventory. Connecticut official town rows are reproducibly aggregated to the nine planning-region county equivalents adopted by the Census Bureau in 2022; those derived current-geography rows are not historical county reporting units.

This archive contains source-aware public election-result summaries for canonical U.S. counties and county equivalents.
It does not contain individual voter records. Advisory indicators and data gaps are not findings of fraud or misconduct.

## Files

- manifest.json: frozen release description, coverage, change log, and limitations
- jurisdictions.csv: canonical county registry and aliases
- county-results-2016.csv, county-results-2020.csv, county-results-2024.csv
- county-comparison-2016-2020.csv, county-comparison-2016-2024.csv, county-comparison-2020-2024.csv
- coverage.json: row-level coverage generated with this archive
- confidence-definitions.json
- data-dictionary.csv
- openapi.json

## Known limitations

- Alaska reports election results through election districts and precinct/reporting units that do not provide a reviewed county-equivalent crosswalk for these years; its 30 Census county equivalents remain unavailable.
- Maine UOCAVA and Rhode Island Federal Precincts are intentional non-geographic historical rows and are excluded from county comparisons.
- Connecticut 2016 and 2020 values are derived current-geography aggregates from official town rows to the nine planning regions adopted as Census county equivalents in 2022; they are not totals reported by those planning regions in those elections.
- Turnout, equipment, vote-method, advisory, and administrative context have different reporting grains and should not be assumed to cover every county.

Retain source, confidence, and caveat fields when redistributing these data.
